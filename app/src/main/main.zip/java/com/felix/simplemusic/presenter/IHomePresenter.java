package com.felix.simplemusic.presenter;


/**
 * Created by chaofei.xue on 2018/8/7.
 */

public interface IHomePresenter {
    void changeToolbarText(int position);
    void tvTitleOnClick();
    void startAnimator(int flag);
}
