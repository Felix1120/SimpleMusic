package com.felix.simplemusic.model;

import com.felix.simplemusic.view.IHomeView;

/**
 * Created by chaofei.xue on 2018/8/7.
 */

public class HomeModel implements IHomeModel {
}
