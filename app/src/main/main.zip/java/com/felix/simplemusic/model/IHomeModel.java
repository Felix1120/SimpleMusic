package com.felix.simplemusic.model;

/**
 * Created by chaofei.xue on 2018/8/7.
 */

public interface IHomeModel {
}
